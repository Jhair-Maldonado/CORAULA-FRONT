(()=>{"use strict";(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TarjetaEstudiante",
    ()=>TarjetaEstudiante
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$UserCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/UserCircleIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$ArrowRight01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/ArrowRight01Icon.js [app-client] (ecmascript)");
'use client';
;
;
;
const TarjetaEstudiante = ({ student })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: `/administrador/alumnos/estudiante/${student.id}`,
        className: "bg-white rounded-xl p-4 border border-line shadow-sm hover:shadow-md hover:border-accent/40 transition-all flex items-center justify-between gap-3 group min-w-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 min-w-0 flex-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-10 h-10 rounded-full bg-accent/10 text-accent font-bold text-xs flex items-center justify-center shrink-0 border border-accent/20 group-hover:scale-105 transition-transform",
                        children: [
                            student.nombres.charAt(0),
                            student.apellidoPaterno.charAt(0)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
                        lineNumber: 14,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col min-w-0 gap-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-ink text-xs font-bold group-hover:text-accent transition-colors break-words",
                                children: student.nombreCompleto
                            }, void 0, false, {
                                fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
                                lineNumber: 18,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            student.studentCode !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-[10px] text-muted break-words",
                                children: [
                                    "Código: ",
                                    student.studentCode
                                ]
                            }, void 0, true, {
                                fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
                                lineNumber: 19,
                                columnNumber: 44
                            }, ("TURBOPACK compile-time value", void 0)),
                            student.dni !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-[10px] text-muted break-words flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$UserCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UserCircleIcon"], {
                                        size: 12,
                                        "aria-hidden": "true",
                                        className: "shrink-0"
                                    }, void 0, false, {
                                        fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
                                        lineNumber: 20,
                                        columnNumber: 110
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    "DNI: ",
                                    student.dni
                                ]
                            }, void 0, true, {
                                fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
                                lineNumber: 20,
                                columnNumber: 36
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[10px] font-bold text-ink bg-neutral border border-line px-2 py-0.5 rounded-full w-fit",
                                children: student.estadoLabel
                            }, void 0, false, {
                                fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
                                lineNumber: 21,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-[10px] text-muted break-words",
                                children: student.tieneMatriculaActiva ? [
                                    student.nivelLabel,
                                    student.grade !== null ? `${student.grade}° grado` : null,
                                    student.sectionName
                                ].filter(Boolean).join(' • ') : 'Sin matrícula activa'
                            }, void 0, false, {
                                fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
                                lineNumber: 22,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
                        lineNumber: 17,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "w-9 h-9 rounded-lg bg-neutral text-muted group-hover:bg-accent group-hover:text-white flex items-center justify-center shrink-0 transition-colors",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$ArrowRight01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowRight01Icon"], {
                    size: 16,
                    "aria-hidden": "true"
                }, void 0, false, {
                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
                    lineNumber: 29,
                    columnNumber: 171
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = TarjetaEstudiante;
var _c;
__turbopack_context__.k.register(_c, "TarjetaEstudiante");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VistaTotalAlumnado
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$Search01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/Search01Icon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$ArrowLeft01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/ArrowLeft01Icon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$ArrowRight02Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/ArrowRight02Icon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$UserCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/UserCircleIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$AlertCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/AlertCircleIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$Clock01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/Clock01Icon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$studentsService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/admin/studentsService.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$adapters$2f$studentAdapter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/adapters/studentAdapter.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$alumnos$2f$components$2f$TarjetaEstudiante$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/feature/admin/vistas/(academico)/alumnos/components/TarjetaEstudiante.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function VistaTotalAlumnado() {
    _s();
    const [searchInput, setSearchInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        page: 0,
        size: 20
    });
    const [revision, setRevision] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [result, setResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const key = JSON.stringify([
        query,
        revision
    ]);
    const loading = result?.key !== key;
    const data = loading ? undefined : result?.data;
    const error = loading ? undefined : result?.error;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VistaTotalAlumnado.useEffect": ()=>{
            let current = true;
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$studentsService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentsService"].list(query).then({
                "VistaTotalAlumnado.useEffect": (data)=>{
                    if (current) setResult({
                        key,
                        data
                    });
                }
            }["VistaTotalAlumnado.useEffect"]).catch({
                "VistaTotalAlumnado.useEffect": (error)=>{
                    if (current) setResult({
                        key,
                        error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$studentsService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentErrorMessage"])(error)
                    });
                }
            }["VistaTotalAlumnado.useEffect"]);
            return ({
                "VistaTotalAlumnado.useEffect": ()=>{
                    current = false;
                }
            })["VistaTotalAlumnado.useEffect"];
        }
    }["VistaTotalAlumnado.useEffect"], [
        query,
        revision,
        key
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full h-full p-6 overflow-y-auto bg-canvas font-sans",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-6xl mx-auto flex flex-col gap-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-accent text-[11px] font-bold tracking-widest uppercase",
                            children: "Alumnado"
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 34,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-ink text-2xl font-bold tracking-tight mt-1",
                            children: "Listado de Alumnos"
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 35,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white border border-line rounded-xl p-3 flex flex-wrap gap-3 items-center shadow-sm text-xs",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            className: "flex gap-2 flex-1 min-w-0 w-full sm:min-w-64",
                            onSubmit: (event)=>{
                                event.preventDefault();
                                setQuery((previous)=>({
                                        ...previous,
                                        search: searchInput.trim() || undefined,
                                        page: 0
                                    }));
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "flex items-center gap-2 flex-1 min-w-0 bg-neutral/50 border border-line rounded-lg px-3 focus-within:border-accent",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$Search01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Search01Icon"], {
                                            size: 16,
                                            "aria-hidden": "true",
                                            className: "text-muted shrink-0"
                                        }, void 0, false, {
                                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                            lineNumber: 43,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            "aria-label": "Buscar alumnos",
                                            placeholder: "Buscar alumnos...",
                                            value: searchInput,
                                            onChange: (e)=>setSearchInput(e.target.value),
                                            className: "w-full min-w-0 min-h-10 bg-transparent text-ink placeholder:text-muted focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                                        }, void 0, false, {
                                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                            lineNumber: 44,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                    lineNumber: 42,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "bg-accent text-white px-3 py-2 min-h-10 rounded-lg font-bold hover:bg-accent/90 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
                                    children: "Buscar"
                                }, void 0, false, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                    lineNumber: 46,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 38,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "flex items-center gap-2 text-[11px] font-bold text-muted",
                            children: [
                                "Nivel",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: query.level ?? '',
                                    onChange: (e)=>setQuery((previous)=>({
                                                ...previous,
                                                level: e.target.value || undefined,
                                                page: 0
                                            })),
                                    className: "bg-neutral/50 border border-line rounded-lg px-3 py-2 min-h-10 text-xs text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "Todos"
                                        }, void 0, false, {
                                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                            lineNumber: 50,
                                            columnNumber: 15
                                        }, this),
                                        Object.entries(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$adapters$2f$studentAdapter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentLevelLabels"]).map(([value, label])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: value,
                                                children: label
                                            }, value, false, {
                                                fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                                lineNumber: 51,
                                                columnNumber: 75
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                    lineNumber: 49,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "flex items-center gap-2 text-[11px] font-bold text-muted",
                            children: [
                                "Grado",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "number",
                                    min: 1,
                                    step: 1,
                                    "aria-label": "Filtrar por grado",
                                    placeholder: "Todos",
                                    value: query.grade ?? '',
                                    onChange: (e)=>{
                                        const grade = e.target.value === '' ? undefined : Number(e.target.value);
                                        if (grade === undefined || Number.isInteger(grade) && grade > 0) setQuery((previous)=>({
                                                ...previous,
                                                grade,
                                                page: 0
                                            }));
                                    },
                                    className: "w-20 bg-neutral/50 border border-line rounded-lg px-3 py-2 min-h-10 text-xs text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
                                }, void 0, false, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                    lineNumber: 55,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 54,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "flex items-center gap-2 text-[11px] font-bold text-muted",
                            children: [
                                "Estado",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: query.status ?? '',
                                    onChange: (e)=>setQuery((previous)=>({
                                                ...previous,
                                                status: e.target.value || undefined,
                                                page: 0
                                            })),
                                    className: "bg-neutral/50 border border-line rounded-lg px-3 py-2 min-h-10 text-xs text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "Todos"
                                        }, void 0, false, {
                                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                            lineNumber: 62,
                                            columnNumber: 15
                                        }, this),
                                        Object.entries(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$adapters$2f$studentAdapter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentStatusLabels"]).map(([value, label])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: value,
                                                children: label
                                            }, value, false, {
                                                fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                                lineNumber: 63,
                                                columnNumber: 76
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                    lineNumber: 61,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 60,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                    lineNumber: 37,
                    columnNumber: 9
                }, this),
                loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "status",
                    className: "p-4 bg-white border border-line rounded-xl shadow-sm text-xs text-muted flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$Clock01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Clock01Icon"], {
                            size: 18,
                            "aria-hidden": "true",
                            className: "text-accent shrink-0"
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 67,
                            columnNumber: 146
                        }, this),
                        "Cargando alumnos..."
                    ]
                }, void 0, true, {
                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                    lineNumber: 67,
                    columnNumber: 21
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    role: "alert",
                    className: "p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "flex items-start gap-2 break-words font-medium",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$AlertCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertCircleIcon"], {
                                    size: 18,
                                    "aria-hidden": "true",
                                    className: "shrink-0"
                                }, void 0, false, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                    lineNumber: 69,
                                    columnNumber: 73
                                }, this),
                                error
                            ]
                        }, void 0, true, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setRevision((n)=>n + 1),
                            className: "mt-3 min-h-10 px-3 py-2 rounded-lg bg-white border border-line font-bold hover:bg-neutral focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
                            children: "Reintentar"
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 70,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                    lineNumber: 68,
                    columnNumber: 19
                }, this),
                data && data.content.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-white border border-line border-dashed p-8 rounded-xl text-center flex flex-col items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$UserCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UserCircleIcon"], {
                            size: 28,
                            "aria-hidden": "true",
                            className: "text-muted"
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 72,
                            columnNumber: 166
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm font-bold text-ink",
                            children: "No se encontraron alumnos con los criterios actuales."
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 72,
                            columnNumber: 236
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-muted",
                            children: "Ajusta los filtros para intentar nuevamente."
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 72,
                            columnNumber: 335
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                    lineNumber: 72,
                    columnNumber: 47
                }, this),
                data && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4",
                    children: data.content.map(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$adapters$2f$studentAdapter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toAdminStudent"]).map((student)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$alumnos$2f$components$2f$TarjetaEstudiante$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TarjetaEstudiante"], {
                            student: student
                        }, student.id, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 74,
                            columnNumber: 60
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                    lineNumber: 73,
                    columnNumber: 18
                }, this),
                data && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-wrap items-center justify-between gap-3 border-t border-line pt-4 text-xs text-muted",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: [
                                data.totalElements,
                                " alumnos • Página ",
                                data.totalPages ? data.page + 1 : 0,
                                " de ",
                                data.totalPages,
                                " • Tamaño ",
                                data.size
                            ]
                        }, void 0, true, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 77,
                            columnNumber: 11
                        }, this),
                        data.totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    "aria-label": "Página anterior",
                                    disabled: data.page <= 0,
                                    onClick: ()=>setQuery((previous)=>({
                                                ...previous,
                                                page: data.page - 1
                                            })),
                                    className: "p-2 min-h-10 min-w-10 bg-white border border-line rounded-lg disabled:opacity-40 disabled:cursor-not-allowed hover:bg-neutral focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$ArrowLeft01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowLeft01Icon"], {
                                        size: 16,
                                        "aria-hidden": "true"
                                    }, void 0, false, {
                                        fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                        lineNumber: 79,
                                        columnNumber: 375
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                    lineNumber: 79,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    "aria-label": "Página siguiente",
                                    disabled: data.page + 1 >= data.totalPages,
                                    onClick: ()=>setQuery((previous)=>({
                                                ...previous,
                                                page: data.page + 1
                                            })),
                                    className: "p-2 min-h-10 min-w-10 bg-white border border-line rounded-lg disabled:opacity-40 disabled:cursor-not-allowed hover:bg-neutral focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$ArrowRight02Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowRight02Icon"], {
                                        size: 16,
                                        "aria-hidden": "true"
                                    }, void 0, false, {
                                        fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                        lineNumber: 80,
                                        columnNumber: 394
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                                    lineNumber: 80,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                            lineNumber: 78,
                            columnNumber: 35
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
                    lineNumber: 76,
                    columnNumber: 18
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
            lineNumber: 32,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_s(VistaTotalAlumnado, "Nc/gfd5JF+wStZvIz+7CKBLtIp4=");
_c = VistaTotalAlumnado;
var _c;
__turbopack_context__.k.register(_c, "VistaTotalAlumnado");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/adapters/studentAdapter.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "guardianRelationshipLabels",
    ()=>guardianRelationshipLabels,
    "studentEditValidation",
    ()=>studentEditValidation,
    "studentFullName",
    ()=>studentFullName,
    "studentLevelLabels",
    ()=>studentLevelLabels,
    "studentStatusLabels",
    ()=>studentStatusLabels,
    "toAdminStudent",
    ()=>toAdminStudent,
    "toAdminStudentDetail",
    ()=>toAdminStudentDetail,
    "toStudentEditValues",
    ()=>toStudentEditValues,
    "toUpdateStudent",
    ()=>toUpdateStudent
]);
const studentLevelLabels = {
    PRIMARY: 'Primaria',
    SECONDARY: 'Secundaria'
};
const studentStatusLabels = {
    ACTIVE: 'Activo',
    WITHDRAWN: 'Retirado',
    GRADUATED: 'Egresado'
};
const enrollmentLabels = {
    ACTIVE: 'Activa',
    WITHDRAWN: 'Retirada',
    COMPLETED: 'Finalizada'
};
const guardianRelationshipLabels = {
    FATHER: 'Padre',
    MOTHER: 'Madre',
    TUTOR: 'Tutor',
    GUARDIAN: 'Apoderado',
    OTHER: 'Otro'
};
function studentFullName(person) {
    return [
        person.firstNames,
        person.paternalLastName,
        person.maternalLastName
    ].filter(Boolean).join(' ');
}
function toAdminStudent(student) {
    return {
        ...student,
        id: String(student.studentId),
        nombres: student.firstNames,
        apellidoPaterno: student.paternalLastName,
        apellidoMaterno: student.maternalLastName,
        nombreCompleto: studentFullName(student),
        nivelLabel: student.level === null ? null : studentLevelLabels[student.level],
        estadoLabel: studentStatusLabels[student.studentStatus],
        matriculaLabel: student.enrollmentStatus === null ? null : enrollmentLabels[student.enrollmentStatus],
        tieneMatriculaActiva: student.enrollmentId !== null && student.enrollmentStatus === 'ACTIVE'
    };
}
function toAdminStudentDetail(student) {
    return {
        ...toAdminStudent(student),
        personId: student.personId,
        phone: student.phone,
        enrollmentDate: student.enrollmentDate,
        guardians: student.guardians
    };
}
function toStudentEditValues(student) {
    return {
        studentCode: student.studentCode ?? '',
        dni: student.dni ?? '',
        firstNames: student.nombres,
        paternalLastName: student.apellidoPaterno,
        maternalLastName: student.apellidoMaterno ?? '',
        birthDate: student.birthDate ?? '',
        phone: student.phone ?? '',
        reason: ''
    };
}
function toUpdateStudent(values, original) {
    const patch = {};
    const previous = toStudentEditValues(original);
    const fields = [
        'studentCode',
        'dni',
        'firstNames',
        'paternalLastName',
        'maternalLastName',
        'birthDate',
        'phone'
    ];
    for (const field of fields){
        const next = values[field].trim();
        if (next !== previous[field].trim()) patch[field] = next;
    }
    if (Object.keys(patch).length) patch.reason = values.reason.trim() || null;
    return patch;
}
function studentEditValidation(values, original) {
    if (!values.firstNames.trim() || !values.paternalLastName.trim()) return 'Nombres y apellido paterno son obligatorios.';
    const limits = {
        studentCode: 50,
        dni: 20,
        firstNames: 120,
        paternalLastName: 120,
        maternalLastName: 120,
        phone: 30
    };
    for (const field of Object.keys(limits)){
        if (values[field].trim().length > limits[field]) return 'Uno de los campos supera la longitud permitida.';
    }
    if (original.studentCode !== null && !values.studentCode.trim()) return 'El backend no permite borrar un código existente.';
    if (original.birthDate !== null && !values.birthDate) return 'El backend no permite borrar una fecha de nacimiento existente.';
    if (values.birthDate) {
        const date = new Date(values.birthDate + 'T00:00:00Z');
        if (!/^\d{4}-\d{2}-\d{2}$/.test(values.birthDate) || Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== values.birthDate) return 'Ingresa una fecha de nacimiento válida.';
    }
    return null;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/administrador/(academico)/alumnos/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AlumnosOverviewPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$alumnos$2f$vistaTotalAlumnado$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/feature/admin/vistas/(academico)/alumnos/vistaTotalAlumnado.tsx [app-client] (ecmascript)");
'use client';
;
;
function AlumnosOverviewPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$alumnos$2f$vistaTotalAlumnado$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/app/administrador/(academico)/alumnos/page.tsx",
            lineNumber: 8,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/administrador/(academico)/alumnos/page.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = AlumnosOverviewPage;
var _c;
__turbopack_context__.k.register(_c, "AlumnosOverviewPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/admin/studentsService.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "studentErrorMessage",
    ()=>studentErrorMessage,
    "studentErrorStatus",
    ()=>studentErrorStatus,
    "studentsService",
    ()=>studentsService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/axios/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$httpClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/httpClient.ts [app-client] (ecmascript)");
;
;
const endpoint = '/v1/management/students';
const studentsService = {
    async list (params = {}) {
        return (await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$httpClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(endpoint, {
            params
        })).data;
    },
    async getById (studentId) {
        return (await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$httpClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${endpoint}/${encodeURIComponent(studentId)}`)).data;
    },
    async update (studentId, payload) {
        return (await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$httpClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].patch(`${endpoint}/${encodeURIComponent(studentId)}`, payload)).data;
    }
};
function studentErrorStatus(error) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isAxiosError"])(error) ? error.response?.status : undefined;
}
function studentErrorMessage(error) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isAxiosError"])(error)) return 'No se pudo completar la solicitud. Intenta nuevamente.';
    if (!error.response) return 'No se pudo conectar con el servidor. Revisa tu conexión e intenta nuevamente.';
    const body = error.response.data;
    const message = typeof body === 'string' && body.trim() ? body : body && typeof body === 'object' && 'message' in body && typeof body.message === 'string' && body.message.trim() ? body.message : undefined;
    switch(error.response.status){
        case 400:
            return message || 'Revisa los datos ingresados; la solicitud no es válida.';
        case 401:
            return 'Tu sesión no permite completar la solicitud.';
        case 403:
            return 'No tienes autorización para realizar esta operación.';
        case 404:
            return 'Alumno no encontrado.';
        case 409:
            return message || 'El DNI o código ya pertenece a otro registro. Revisa los datos.';
        default:
            return 'El servidor no pudo completar la solicitud. Intenta nuevamente.';
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/httpClient.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
/**
 * Cliente HTTP estandarizado (Axios).
 * Configurado con la URL base del entorno.
 */ const httpClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:8080/api',
    headers: {
        'Content-Type': 'application/json'
    }
});
/**
 * Interceptor de Solicitudes (Request).
 * Adjunta el Bearer Token a todas las peticiones salientes si existe sesión.
 */ httpClient.interceptors.request.use((config)=>{
    if ("TURBOPACK compile-time truthy", 1) {
        const token = localStorage.getItem('token');
        if (token && config.headers) {
            config.headers.Authorization = `Bearer ${token}`;
        }
    }
    return config;
}, (error)=>Promise.reject(error));
/**
 * Interceptor de Respuestas (Response).
 * Atrapa los errores HTTP de forma global antes de que lleguen a los servicios.
 */ httpClient.interceptors.response.use((response)=>response, (error)=>{
    if (error.response?.status === 401) {
        if ("TURBOPACK compile-time truthy", 1) {
            // Se omite la expulsión si el error proviene del propio intento de login (401 de credenciales erróneas),
            // asegurando que sólo se expulsa cuando falla un token válido previamente asignado.
            const hasAuthHeader = !!error.config?.headers?.Authorization;
            if (hasAuthHeader) {
                window.dispatchEvent(new CustomEvent('auth:unauthorized'));
            }
        }
    }
    return Promise.reject(error);
});
const __TURBOPACK__default__export__ = httpClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);})()

//# sourceMappingURL=_1o7z66xc21ak0._.js.map