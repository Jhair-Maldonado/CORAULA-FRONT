(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_1gdxm4-15jjh5._.js","static/chunks/src_app_globals_162hn9oqc8uss.css","static/chunks/node_modules_11mv_hyfit8pk._.js","static/chunks/_0xalvszxyo3na._.js","static/chunks/1tf9_admin_vistas_(academico)_alumnos_components_GradosSidebar_tsx_1d45utp6o-t7h._.js","static/chunks/node_modules_0il-gg8hhi9fz._.js","static/chunks/_1o7z66xc21ak0._.js"],
    source: "entry"
});
