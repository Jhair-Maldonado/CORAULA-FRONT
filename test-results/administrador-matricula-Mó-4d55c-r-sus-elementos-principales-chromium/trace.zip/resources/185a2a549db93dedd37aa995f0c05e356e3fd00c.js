(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_1gdxm4-15jjh5._.js","static/chunks/src_app_globals_162hn9oqc8uss.css","static/chunks/node_modules_11mv_hyfit8pk._.js","static/chunks/_0xalvszxyo3na._.js","static/chunks/node_modules_axios_0bshbgvuer3nm._.js","static/chunks/_147ux-sqnxwnf._.js"],
    source: "entry"
});
