(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_1gdxm4-15jjh5._.js","static/chunks/src_app_globals_162hn9oqc8uss.css","static/chunks/_1tldxtf5criat._.js","static/chunks/node_modules_1dmwi8gik06-k._.js"],
    source: "entry"
});
