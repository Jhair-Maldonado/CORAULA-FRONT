(()=>{"use strict";(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/feature/admin/vistas/(administrativo)/matricula/pantallaVistaMatricula.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PantallaVistaMatricula
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$feature$2f$admin$2f$component$2f$ImportadorMatricula$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/feature/admin/component/ImportadorMatricula.tsx [app-client] (ecmascript)");
'use client';
;
;
function PantallaVistaMatricula() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full h-full p-6 overflow-y-auto bg-canvas font-sans",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto flex flex-col gap-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-accent text-xs font-bold tracking-widest uppercase",
                            children: "Módulo administrativo"
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(administrativo)/matricula/pantallaVistaMatricula.tsx",
                            lineNumber: 10,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-ink text-2xl font-bold mt-1",
                            children: "Importación y Matrícula Masiva"
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(administrativo)/matricula/pantallaVistaMatricula.tsx",
                            lineNumber: 11,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-muted text-sm mt-1",
                            children: "Carga un archivo .XLSX y valida sus filas con el servidor antes de confirmar."
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(administrativo)/matricula/pantallaVistaMatricula.tsx",
                            lineNumber: 12,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/feature/admin/vistas/(administrativo)/matricula/pantallaVistaMatricula.tsx",
                    lineNumber: 9,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$feature$2f$admin$2f$component$2f$ImportadorMatricula$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/feature/admin/vistas/(administrativo)/matricula/pantallaVistaMatricula.tsx",
                    lineNumber: 14,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/feature/admin/vistas/(administrativo)/matricula/pantallaVistaMatricula.tsx",
            lineNumber: 8,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/feature/admin/vistas/(administrativo)/matricula/pantallaVistaMatricula.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = PantallaVistaMatricula;
var _c;
__turbopack_context__.k.register(_c, "PantallaVistaMatricula");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/administrador/(administrativo)/matricula/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MatriculaPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$administrativo$292f$matricula$2f$pantallaVistaMatricula$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/feature/admin/vistas/(administrativo)/matricula/pantallaVistaMatricula.tsx [app-client] (ecmascript)");
'use client';
;
;
function MatriculaPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$administrativo$292f$matricula$2f$pantallaVistaMatricula$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/src/app/administrador/(administrativo)/matricula/page.tsx",
            lineNumber: 7,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/administrador/(administrativo)/matricula/page.tsx",
        lineNumber: 6,
        columnNumber: 5
    }, this);
}
_c = MatriculaPage;
var _c;
__turbopack_context__.k.register(_c, "MatriculaPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/feature/admin/component/ImportadorMatricula.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ImportadorMatricula
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$studentImportService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/admin/studentImportService.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function Issues({ issues, warning = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
        className: "flex flex-col gap-2",
        children: issues.map((issue, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                className: `rounded-lg p-2 ${warning ? 'bg-amber-50 text-amber-900' : 'bg-red-50 text-red-800'}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs font-bold rounded border border-current px-1",
                        "data-issue-code": issue.code,
                        children: issue.code
                    }, void 0, false, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 10,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-1",
                        children: [
                            issue.field,
                            ": ",
                            issue.message
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 11,
                        columnNumber: 7
                    }, this)
                ]
            }, `${issue.code}-${issue.field}-${index}`, true, {
                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                lineNumber: 9,
                columnNumber: 5
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
        lineNumber: 8,
        columnNumber: 10
    }, this);
}
_c = Issues;
function ImportadorMatricula() {
    _s();
    const [selectedFile, setSelectedFile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [previewLoading, setPreviewLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [preview, setPreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [previewFile, setPreviewFile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [previewError, setPreviewError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [confirmLoading, setConfirmLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [confirmation, setConfirmation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [confirmError, setConfirmError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [needsNewPreview, setNeedsNewPreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Synchronous locks prevent repeated clicks before React updates state.
    const requestInProgress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const confirmed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const busy = previewLoading || confirmLoading;
    const canConfirm = !!selectedFile && !!preview && previewFile === selectedFile && preview.totalRows > 0 && preview.invalidRows === 0 && preview.validRows === preview.totalRows && preview.rows.length === preview.totalRows && preview.rows.every((row)=>row.valid === true && row.errors.length === 0) && !busy && !confirmation && !needsNewPreview;
    const selectFile = (file)=>{
        if (requestInProgress.current) return;
        setPreview(null);
        setPreviewFile(null);
        setConfirmation(null);
        setPreviewError(null);
        setConfirmError(null);
        setNeedsNewPreview(false);
        confirmed.current = false;
        if (!/\.xlsx$/i.test(file.name)) {
            setSelectedFile(null);
            setPreviewError('Solo se permiten archivos .XLSX.');
            return;
        }
        setSelectedFile(file);
    };
    const requestPreview = async ()=>{
        if (!selectedFile || requestInProgress.current || confirmed.current) return;
        const file = selectedFile;
        requestInProgress.current = true;
        setPreviewLoading(true);
        setPreview(null);
        setPreviewFile(null);
        setPreviewError(null);
        setConfirmError(null);
        setNeedsNewPreview(false);
        try {
            setPreview(await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$studentImportService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentImportService"].preview(file));
            setPreviewFile(file);
        } catch (error) {
            const refreshedPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$studentImportService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentImportErrorPreview"])(error);
            if (refreshedPreview) {
                setPreview(refreshedPreview);
                setPreviewFile(file);
                setNeedsNewPreview(true);
            }
            setPreviewError((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$studentImportService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentImportErrorMessage"])(error));
        } finally{
            requestInProgress.current = false;
            setPreviewLoading(false);
        }
    };
    const requestConfirmation = async ()=>{
        if (!canConfirm || !selectedFile || requestInProgress.current || confirmed.current) return;
        const file = selectedFile;
        requestInProgress.current = true;
        setConfirmLoading(true);
        setConfirmError(null);
        try {
            const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$studentImportService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentImportService"].confirm(file);
            confirmed.current = true;
            setConfirmation(result);
        } catch (error) {
            const refreshedPreview = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$studentImportService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentImportErrorPreview"])(error);
            if (refreshedPreview) {
                setPreview(refreshedPreview);
                setPreviewFile(file);
                // An error response never re-enables confirmation, even if counters look valid.
                setNeedsNewPreview(true);
            }
            setConfirmError((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$studentImportService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["studentImportErrorMessage"])(error));
        } finally{
            requestInProgress.current = false;
            setConfirmLoading(false);
        }
    };
    const buttonClass = 'px-4 py-2 rounded-xl bg-accent text-white text-sm font-bold disabled:opacity-50 disabled:cursor-not-allowed';
    const display = (value)=>value ?? '—';
    const fullName = (...parts)=>parts.filter(Boolean).join(' ') || '—';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "w-full bg-white rounded-2xl border border-line p-6 flex flex-col gap-5",
        "aria-busy": busy,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                onDragOver: (event)=>event.preventDefault(),
                onDrop: (event)=>{
                    event.preventDefault();
                    const file = event.dataTransfer.files[0];
                    if (file) selectFile(file);
                },
                className: "border-2 border-dashed border-line rounded-xl p-8 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-ink font-bold",
                        children: "Selecciona o arrastra un archivo .XLSX"
                    }, void 0, false, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 121,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-muted mt-2",
                        children: "Usa la hoja ESTUDIANTES con las 21 columnas del contrato V2. El servidor revisará su estructura y la validez de cada fila."
                    }, void 0, false, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 122,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: fileInputRef,
                        type: "file",
                        accept: ".xlsx",
                        disabled: busy,
                        "aria-label": "Seleccionar archivo de matrícula .XLSX",
                        className: "mt-4 max-w-full text-sm",
                        onChange: (event)=>{
                            const file = event.target.files?.[0];
                            if (file) selectFile(file);
                            event.target.value = '';
                        }
                    }, void 0, false, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 123,
                        columnNumber: 9
                    }, this),
                    confirmation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: `${buttonClass} mt-4`,
                        onClick: ()=>fileInputRef.current?.click(),
                        children: "Cargar otro archivo"
                    }, void 0, false, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 136,
                        columnNumber: 26
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                lineNumber: 112,
                columnNumber: 7
            }, this),
            selectedFile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-ink",
                        children: [
                            "Archivo: ",
                            selectedFile.name
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 140,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: buttonClass,
                        disabled: busy || !!confirmation,
                        onClick: requestPreview,
                        children: previewLoading ? 'Validando en servidor...' : 'Obtener preview'
                    }, void 0, false, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 141,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        className: buttonClass,
                        disabled: !canConfirm,
                        onClick: requestConfirmation,
                        children: confirmLoading ? 'Confirmando...' : 'Confirmar matrícula'
                    }, void 0, false, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 144,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                lineNumber: 139,
                columnNumber: 9
            }, this),
            selectedFile && !preview && !confirmation && !previewLoading && !previewError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-muted",
                children: "Archivo seleccionado. Pendiente de validación por el servidor."
            }, void 0, false, {
                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                lineNumber: 150,
                columnNumber: 9
            }, this),
            previewError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                className: "text-sm text-red-700",
                children: previewError
            }, void 0, false, {
                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                lineNumber: 152,
                columnNumber: 24
            }, this),
            confirmError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                role: "alert",
                className: "text-sm text-red-700",
                children: confirmError
            }, void 0, false, {
                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                lineNumber: 153,
                columnNumber: 24
            }, this),
            needsNewPreview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-muted",
                children: "Revisa el resultado actualizado. Obtén un nuevo preview antes de volver a confirmar."
            }, void 0, false, {
                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                lineNumber: 154,
                columnNumber: 27
            }, this),
            preview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-ink",
                        children: [
                            "Total: ",
                            preview.totalRows,
                            " · Válidas: ",
                            preview.validRows,
                            " · Inválidas: ",
                            preview.invalidRows
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 157,
                        columnNumber: 11
                    }, this),
                    preview.invalidRows > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-red-700",
                        children: "Corrige el archivo y vuelve a validarlo antes de confirmar."
                    }, void 0, false, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 158,
                        columnNumber: 39
                    }, this),
                    preview.validRows === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-muted",
                        children: "No hay filas válidas para confirmar."
                    }, void 0, false, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 159,
                        columnNumber: 39
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-h-[36rem] overflow-auto border border-line rounded-xl",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                            className: "w-full text-left text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("caption", {
                                    className: "p-3 text-muted text-left",
                                    children: "Resultado de validación por fila. Las advertencias no bloquean la confirmación."
                                }, void 0, false, {
                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                    lineNumber: 162,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        children: [
                                            'Fila / Estado',
                                            'Estudiante',
                                            'Apoderado',
                                            'Académico',
                                            'Errores / Advertencias'
                                        ].map((label)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                scope: "col",
                                                className: "p-3",
                                                children: label
                                            }, label, false, {
                                                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                lineNumber: 163,
                                                columnNumber: 124
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                        lineNumber: 163,
                                        columnNumber: 22
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                    lineNumber: 163,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                    children: preview.rows.map((row, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            className: "border-t border-line align-top",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "p-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "Fila ",
                                                                row.rowNumber
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 168,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: `inline-block rounded px-2 py-1 mt-1 ${row.valid && row.errors.length === 0 ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-800'}`,
                                                            children: row.valid && row.errors.length === 0 ? 'Válida' : 'Inválida'
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 169,
                                                            columnNumber: 23
                                                        }, this),
                                                        row.warnings.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "inline-block rounded px-2 py-1 mt-1 bg-amber-50 text-amber-900",
                                                            children: [
                                                                row.warnings.length,
                                                                " advertencias"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 170,
                                                            columnNumber: 51
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                    lineNumber: 167,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "p-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: fullName(row.data.studentFirstNames, row.data.studentLastNamePaternal, row.data.studentLastNameMaternal)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 173,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "DNI: ",
                                                                display(row.data.studentDni)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 174,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "break-all",
                                                            children: [
                                                                "Email: ",
                                                                display(row.data.studentEmail)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 175,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "Fecha de nacimiento: ",
                                                                display(row.data.studentBirthDate)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 176,
                                                            columnNumber: 23
                                                        }, this),
                                                        row.data.studentPhone && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "Teléfono: ",
                                                                row.data.studentPhone
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 177,
                                                            columnNumber: 49
                                                        }, this),
                                                        row.data.studentCode != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "Código: ",
                                                                row.data.studentCode
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 178,
                                                            columnNumber: 56
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                    lineNumber: 172,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "p-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: fullName(row.data.guardianFirstNames, row.data.guardianLastNamePaternal, row.data.guardianLastNameMaternal)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 181,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "DNI: ",
                                                                display(row.data.guardianDni)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 182,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "Relación: ",
                                                                display(row.data.guardianRelationship)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 183,
                                                            columnNumber: 23
                                                        }, this),
                                                        row.data.guardianEmail && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "break-all",
                                                            children: [
                                                                "Email: ",
                                                                row.data.guardianEmail
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 184,
                                                            columnNumber: 50
                                                        }, this),
                                                        row.data.guardianPhone && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "Teléfono: ",
                                                                row.data.guardianPhone
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 185,
                                                            columnNumber: 50
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                    lineNumber: 180,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "p-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "Periodo: ",
                                                                display(row.data.academicPeriod)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 188,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "Nivel: ",
                                                                display(row.data.level)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 189,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "Grado: ",
                                                                display(row.data.grade)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 190,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "Sección: ",
                                                                display(row.data.section)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 191,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                "Fecha: ",
                                                                display(row.data.enrollmentDate)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 192,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                    lineNumber: 187,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                    className: "p-3 min-w-64",
                                                    children: [
                                                        row.errors.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "font-bold mb-1",
                                                                    children: "Errores"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                                    lineNumber: 195,
                                                                    columnNumber: 50
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Issues, {
                                                                    issues: row.errors
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                                    lineNumber: 195,
                                                                    columnNumber: 91
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 195,
                                                            columnNumber: 48
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: "Sin errores"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 195,
                                                            columnNumber: 127
                                                        }, this),
                                                        row.warnings.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "mt-3",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "font-bold mb-1",
                                                                    children: "Advertencias"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                                    lineNumber: 196,
                                                                    columnNumber: 73
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Issues, {
                                                                    issues: row.warnings,
                                                                    warning: true
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                                    lineNumber: 196,
                                                                    columnNumber: 119
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                            lineNumber: 196,
                                                            columnNumber: 51
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                                    lineNumber: 194,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, `${row.rowNumber}-${index}`, true, {
                                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                            lineNumber: 166,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                    lineNumber: 164,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                            lineNumber: 161,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 160,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                lineNumber: 156,
                columnNumber: 9
            }, this),
            confirmation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                role: "status",
                className: "rounded-xl p-4 bg-emerald-50 text-emerald-800 text-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "font-bold",
                        children: "Confirmación recibida del servidor"
                    }, void 0, false, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 207,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "mt-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Filas procesadas: ",
                                    confirmation.totalRows
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                lineNumber: 209,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Estudiantes creados: ",
                                    confirmation.studentsCreated
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                lineNumber: 210,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Apoderados creados: ",
                                    confirmation.guardiansCreated
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                lineNumber: 211,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Apoderados reutilizados por relación: ",
                                    confirmation.guardiansReused
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                lineNumber: 212,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Usuarios creados: ",
                                    confirmation.usersCreated
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                lineNumber: 213,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Relaciones creadas: ",
                                    confirmation.relationshipsCreated
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                lineNumber: 214,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: [
                                    "Matrículas creadas: ",
                                    confirmation.enrollmentsCreated
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                                lineNumber: 215,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                        lineNumber: 208,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
                lineNumber: 206,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/feature/admin/component/ImportadorMatricula.tsx",
        lineNumber: 111,
        columnNumber: 5
    }, this);
}
_s(ImportadorMatricula, "aaHe3uyi69rxCylGnDAud35SoQI=");
_c1 = ImportadorMatricula;
var _c, _c1;
__turbopack_context__.k.register(_c, "Issues");
__turbopack_context__.k.register(_c1, "ImportadorMatricula");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/admin/studentImportService.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "studentImportErrorMessage",
    ()=>studentImportErrorMessage,
    "studentImportErrorPreview",
    ()=>studentImportErrorPreview,
    "studentImportService",
    ()=>studentImportService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/axios/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$httpClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/httpClient.ts [app-client] (ecmascript)");
;
;
async function upload(action, file) {
    const form = new FormData();
    form.append('file', file);
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$httpClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(`/v1/management/students/import/${action}`, form, // Override the client's JSON default; browser supplies multipart boundary.
    {
        headers: {
            'Content-Type': undefined
        }
    });
    return response.data;
}
const studentImportService = {
    preview: (file)=>upload('preview', file),
    confirm: (file)=>upload('confirm', file)
};
function studentImportErrorMessage(error) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isAxiosError"])(error)) return 'No se pudo completar la solicitud. Intenta nuevamente.';
    const status = error.response?.status;
    const body = error.response?.data;
    // Defensive extraction, without declaring an unconfirmed error-envelope contract.
    const message = typeof body === 'string' ? body : body && typeof body === 'object' && 'message' in body && typeof body.message === 'string' ? body.message : null;
    if (status === 400) return message || 'El archivo o su estructura no son válidos.';
    if (status === 401) return 'La sesión no permite completar la solicitud.';
    if (status === 403) return message || 'No tienes autorización para importar matrículas.';
    if (status === 409) return message || 'Existe un conflicto al confirmar la matrícula. Revisa el archivo.';
    return message ? `${message} — Intenta nuevamente.` : 'No se pudo conectar o completar la solicitud. Intenta nuevamente.';
}
function studentImportErrorPreview(error) {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isAxiosError"])(error) || ![
        400,
        409
    ].includes(error.response?.status ?? 0)) return null;
    return error.response?.data?.preview ?? null;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/httpClient.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
/**
 * Cliente HTTP estandarizado (Axios).
 * Configurado con la URL base del entorno.
 */ const httpClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:8080/api',
    headers: {
        'Content-Type': 'application/json'
    }
});
/**
 * Interceptor de Solicitudes (Request).
 * Adjunta el Bearer Token a todas las peticiones salientes si existe sesión.
 */ httpClient.interceptors.request.use((config)=>{
    if ("TURBOPACK compile-time truthy", 1) {
        const token = localStorage.getItem('token');
        if (token && config.headers) {
            config.headers.Authorization = `Bearer ${token}`;
        }
    }
    return config;
}, (error)=>Promise.reject(error));
/**
 * Interceptor de Respuestas (Response).
 * Atrapa los errores HTTP de forma global antes de que lleguen a los servicios.
 */ httpClient.interceptors.response.use((response)=>response, (error)=>{
    if (error.response?.status === 401) {
        if ("TURBOPACK compile-time truthy", 1) {
            // Se omite la expulsión si el error proviene del propio intento de login (401 de credenciales erróneas),
            // asegurando que sólo se expulsa cuando falla un token válido previamente asignado.
            const hasAuthHeader = !!error.config?.headers?.Authorization;
            if (hasAuthHeader) {
                window.dispatchEvent(new CustomEvent('auth:unauthorized'));
            }
        }
    }
    return Promise.reject(error);
});
const __TURBOPACK__default__export__ = httpClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);})()

//# sourceMappingURL=_147ux-sqnxwnf._.js.map