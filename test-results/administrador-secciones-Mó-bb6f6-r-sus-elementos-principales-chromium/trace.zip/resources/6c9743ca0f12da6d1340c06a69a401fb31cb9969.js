(()=>{"use strict";(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Failure",
    ()=>Failure,
    "SectionBadge",
    ()=>SectionBadge,
    "SectionDialog",
    ()=>SectionDialog,
    "SectionEmpty",
    ()=>SectionEmpty,
    "SectionIdentity",
    ()=>SectionIdentity,
    "SectionLoading",
    ()=>SectionLoading,
    "buttonClass",
    ()=>buttonClass,
    "destructiveButtonClass",
    ()=>destructiveButtonClass,
    "inputClass",
    ()=>inputClass,
    "labelClass",
    ()=>labelClass,
    "primaryButtonClass",
    ()=>primaryButtonClass,
    "secondaryButtonClass",
    ()=>secondaryButtonClass,
    "sectionName",
    ()=>sectionName
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$AlertCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/AlertCircleIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$Cancel01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/Cancel01Icon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$School01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/School01Icon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$Clock01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/Clock01Icon.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const buttonClass = 'min-h-10 px-3 py-2 rounded-xl border border-line text-xs font-bold transition-colors hover:brightness-95 disabled:opacity-50 disabled:cursor-not-allowed focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent';
const inputClass = 'min-h-10 min-w-0 px-3 py-2 rounded-lg border border-line bg-neutral/50 text-xs font-medium text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent';
const labelClass = 'flex flex-col gap-1.5 text-[10px] font-bold text-muted uppercase tracking-wider';
const primaryButtonClass = `${buttonClass} bg-accent text-white shadow-sm`;
const secondaryButtonClass = `${buttonClass} bg-white text-ink hover:bg-neutral`;
const destructiveButtonClass = `${buttonClass} bg-white text-rose-700 border-rose-200 hover:bg-rose-50`;
const sectionName = (name)=>/^sección\b/i.test(name) ? name : `Sección ${name}`;
function SectionBadge({ positive, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: `inline-flex w-fit px-2 py-1 rounded-md border text-[10px] font-bold whitespace-nowrap ${positive ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-neutral text-muted border-line'}`,
        children: children
    }, void 0, false, {
        fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
        lineNumber: 16,
        columnNumber: 10
    }, this);
}
_c = SectionBadge;
function SectionLoading({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "status",
        className: "flex items-center gap-2.5 p-4 bg-white border border-line rounded-xl shadow-sm text-xs font-medium text-muted",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$Clock01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Clock01Icon"], {
                size: 18,
                "aria-hidden": "true",
                className: "shrink-0 text-accent"
            }, void 0, false, {
                fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                lineNumber: 20,
                columnNumber: 151
            }, this),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
        lineNumber: 20,
        columnNumber: 10
    }, this);
}
_c1 = SectionLoading;
function SectionEmpty({ title, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-white border border-dashed border-line rounded-xl p-8 flex flex-col items-center gap-2 text-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$School01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["School01Icon"], {
                size: 28,
                "aria-hidden": "true",
                className: "text-muted"
            }, void 0, false, {
                fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                lineNumber: 24,
                columnNumber: 129
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm font-bold text-ink",
                children: title
            }, void 0, false, {
                fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                lineNumber: 24,
                columnNumber: 197
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs text-muted max-w-lg",
                children: children
            }, void 0, false, {
                fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                lineNumber: 24,
                columnNumber: 250
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
        lineNumber: 24,
        columnNumber: 10
    }, this);
}
_c2 = SectionEmpty;
function SectionIdentity({ section }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
        className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs",
        children: [
            [
                'Nivel',
                section.level === 'PRIMARY' ? 'Primaria' : 'Secundaria'
            ],
            [
                'Grado',
                section.grade
            ],
            [
                'Sección',
                sectionName(section.name)
            ],
            [
                'Capacidad',
                section.maxCapacity
            ],
            [
                'Matrícula',
                section.enrollmentOpen ? 'Abierta' : 'Cerrada'
            ],
            [
                'Estado',
                section.active ? 'Activo' : 'Inactivo'
            ]
        ].map(([label, value])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "min-w-0 p-3 bg-neutral/50 border border-line rounded-xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                        className: "text-muted text-[10px] font-bold uppercase tracking-wider mb-1.5",
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                        lineNumber: 34,
                        columnNumber: 116
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                        className: "font-bold break-words",
                        children: label === 'Matrícula' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionBadge, {
                            positive: section.enrollmentOpen,
                            children: value
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                            lineNumber: 34,
                            columnNumber: 272
                        }, this) : label === 'Estado' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SectionBadge, {
                            positive: section.active,
                            children: value
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                            lineNumber: 34,
                            columnNumber: 366
                        }, this) : value
                    }, void 0, false, {
                        fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                        lineNumber: 34,
                        columnNumber: 209
                    }, this)
                ]
            }, label, true, {
                fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                lineNumber: 34,
                columnNumber: 31
            }, this))
    }, void 0, false, {
        fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
        lineNumber: 28,
        columnNumber: 10
    }, this);
}
_c3 = SectionIdentity;
function Failure({ message, retry }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "alert",
        className: "p-4 rounded-xl border border-rose-200 bg-rose-50 text-rose-800 text-xs shadow-sm",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-start gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$AlertCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AlertCircleIcon"], {
                        size: 18,
                        "aria-hidden": "true",
                        className: "shrink-0 mt-0.5"
                    }, void 0, false, {
                        fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                        lineNumber: 40,
                        columnNumber: 45
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "whitespace-pre-wrap break-words font-medium leading-relaxed",
                        children: message
                    }, void 0, false, {
                        fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                        lineNumber: 40,
                        columnNumber: 121
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                lineNumber: 40,
                columnNumber: 5
            }, this),
            retry && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: `${secondaryButtonClass} mt-3`,
                onClick: retry,
                children: "Reintentar"
            }, void 0, false, {
                fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                lineNumber: 41,
                columnNumber: 15
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
        lineNumber: 39,
        columnNumber: 10
    }, this);
}
_c4 = Failure;
function SectionDialog({ title, busy, onClose, children }) {
    _s();
    const container = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SectionDialog.useEffect": ()=>{
            const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
            const previousOverflow = document.body.style.overflow;
            document.body.style.overflow = 'hidden';
            container.current?.focus();
            return ({
                "SectionDialog.useEffect": ()=>{
                    document.body.style.overflow = previousOverflow;
                    previous?.focus();
                }
            })["SectionDialog.useEffect"];
        }
    }["SectionDialog.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 bg-ink/40 backdrop-blur-xs flex items-center justify-center p-4",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: container,
            tabIndex: -1,
            role: "dialog",
            "aria-modal": "true",
            "aria-labelledby": "section-dialog-title",
            "aria-busy": busy,
            className: "w-full max-w-xl max-h-[90vh] overflow-y-auto bg-white border border-line border-t-4 border-t-accent rounded-2xl p-5 sm:p-6 shadow-xl text-ink font-sans",
            onKeyDown: (event)=>{
                if (event.key === 'Escape' && !busy) {
                    event.stopPropagation();
                    onClose();
                }
                if (event.key === 'Tab') {
                    const nodes = container.current?.querySelectorAll('button:not(:disabled), input:not(:disabled), select:not(:disabled), [tabindex="0"]');
                    if (!nodes?.length) {
                        event.preventDefault();
                        return;
                    }
                    const first = nodes[0], last = nodes[nodes.length - 1];
                    if (event.shiftKey && (document.activeElement === first || document.activeElement === container.current)) {
                        event.preventDefault();
                        last.focus();
                    } else if (!event.shiftKey && (document.activeElement === last || document.activeElement === container.current)) {
                        event.preventDefault();
                        first.focus();
                    }
                }
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between gap-3 border-b border-line pb-3 mb-5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            id: "section-dialog-title",
                            className: "text-base font-bold tracking-tight",
                            children: title
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                            lineNumber: 67,
                            columnNumber: 95
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            disabled: busy,
                            onClick: onClose,
                            "aria-label": "Cerrar diálogo",
                            className: "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 text-muted hover:bg-neutral hover:text-ink transition-colors disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-accent",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$Cancel01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Cancel01Icon"], {
                                size: 18,
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                                lineNumber: 67,
                                columnNumber: 477
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                            lineNumber: 67,
                            columnNumber: 184
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
                    lineNumber: 67,
                    columnNumber: 7
                }, this),
                children
            ]
        }, void 0, true, {
            fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
            lineNumber: 55,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx",
        lineNumber: 54,
        columnNumber: 10
    }, this);
}
_s(SectionDialog, "gP936EAkbq44zYYGRnj90r2fLhg=");
_c5 = SectionDialog;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "SectionBadge");
__turbopack_context__.k.register(_c1, "SectionLoading");
__turbopack_context__.k.register(_c2, "SectionEmpty");
__turbopack_context__.k.register(_c3, "SectionIdentity");
__turbopack_context__.k.register(_c4, "Failure");
__turbopack_context__.k.register(_c5, "SectionDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VistaSecciones
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$FilterIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/FilterIcon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$BookOpen01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/BookOpen01Icon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$ArrowRight01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hugeicons-react/dist/esm/icons/ArrowRight01Icon.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$sectionsService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/admin/sectionsService.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$sectionErrors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/admin/sectionErrors.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/feature/admin/vistas/(academico)/secciones/sectionUi.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function VistaSecciones() {
    _s();
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [revision, setRevision] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [result, setResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    const key = JSON.stringify([
        query,
        revision
    ]);
    const loading = result?.key !== key;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "VistaSecciones.useEffect": ()=>{
            let current = true;
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$sectionsService$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sectionsService"].list(query).then({
                "VistaSecciones.useEffect": (data)=>{
                    if (current) setResult({
                        key,
                        data
                    });
                }
            }["VistaSecciones.useEffect"]).catch({
                "VistaSecciones.useEffect": (error)=>{
                    if (current) setResult({
                        key,
                        error: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$admin$2f$sectionErrors$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sectionErrorMessage"])(error)
                    });
                }
            }["VistaSecciones.useEffect"]);
            return ({
                "VistaSecciones.useEffect": ()=>{
                    current = false;
                }
            })["VistaSecciones.useEffect"];
        }
    }["VistaSecciones.useEffect"], [
        query,
        key
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-6 overflow-y-auto h-full bg-canvas text-ink font-sans",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto flex flex-col gap-5",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-accent text-[11px] font-bold uppercase tracking-widest",
                            children: "Académico"
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                            lineNumber: 25,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "text-2xl font-bold tracking-tight mt-0.5",
                            children: "Secciones"
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                            lineNumber: 25,
                            columnNumber: 103
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-muted text-xs font-medium mt-1",
                            children: "Consulta las secciones y gestiona sus cursos y docentes asignados."
                        }, void 0, false, {
                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                            lineNumber: 25,
                            columnNumber: 174
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                    lineNumber: 25,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col sm:flex-row sm:items-end flex-wrap gap-3 p-3 bg-white border border-line rounded-xl shadow-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 text-xs font-bold text-ink sm:self-center sm:mr-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$FilterIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterIcon"], {
                                    size: 16,
                                    "aria-hidden": "true",
                                    className: "text-accent"
                                }, void 0, false, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                    lineNumber: 27,
                                    columnNumber: 100
                                }, this),
                                "Filtros de vista"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                            lineNumber: 27,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["labelClass"],
                            children: [
                                "Nivel",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputClass"],
                                    value: query.level ?? '',
                                    onChange: (event)=>setQuery((previous)=>({
                                                ...previous,
                                                level: event.target.value === '' ? undefined : event.target.value
                                            })),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "Todos"
                                        }, void 0, false, {
                                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                            lineNumber: 30,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "PRIMARY",
                                            children: "Primaria"
                                        }, void 0, false, {
                                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                            lineNumber: 30,
                                            columnNumber: 44
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "SECONDARY",
                                            children: "Secundaria"
                                        }, void 0, false, {
                                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                            lineNumber: 30,
                                            columnNumber: 85
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                    lineNumber: 29,
                                    columnNumber: 11
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                            lineNumber: 28,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["labelClass"],
                            children: [
                                "Grado",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputClass"],
                                    type: "number",
                                    min: 1,
                                    step: 1,
                                    placeholder: "Todos",
                                    value: query.grade ?? '',
                                    onChange: (event)=>{
                                        const value = event.target.valueAsNumber;
                                        if (event.target.value === '' || Number.isInteger(value) && value > 0) setQuery((previous)=>({
                                                ...previous,
                                                grade: event.target.value === '' ? undefined : value
                                            }));
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                    lineNumber: 34,
                                    columnNumber: 11
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                            lineNumber: 33,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["labelClass"],
                            children: [
                                "Estado",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inputClass"],
                                    value: query.active === undefined ? '' : String(query.active),
                                    onChange: (event)=>setQuery((previous)=>({
                                                ...previous,
                                                active: event.target.value === '' ? undefined : event.target.value === 'true'
                                            })),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "Todos"
                                        }, void 0, false, {
                                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                            lineNumber: 41,
                                            columnNumber: 13
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "true",
                                            children: "Activos"
                                        }, void 0, false, {
                                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                            lineNumber: 41,
                                            columnNumber: 44
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "false",
                                            children: "Inactivos"
                                        }, void 0, false, {
                                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                            lineNumber: 41,
                                            columnNumber: 81
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                    lineNumber: 40,
                                    columnNumber: 11
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                            lineNumber: 39,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                    lineNumber: 26,
                    columnNumber: 7
                }, this),
                loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionLoading"], {
                    children: "Cargando secciones..."
                }, void 0, false, {
                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                    lineNumber: 45,
                    columnNumber: 18
                }, this) : result?.error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Failure"], {
                    message: result.error,
                    retry: ()=>setRevision((n)=>n + 1)
                }, void 0, false, {
                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                    lineNumber: 45,
                    columnNumber: 91
                }, this) : result?.data && (result.data.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionEmpty"], {
                    title: "No se encontraron secciones",
                    children: "Ajusta los filtros para intentar nuevamente."
                }, void 0, false, {
                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                    lineNumber: 46,
                    columnNumber: 36
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "overflow-x-auto bg-white border border-line rounded-xl shadow-sm",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: "w-full text-left text-xs",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                className: "bg-neutral/60 text-[10px] font-bold text-muted uppercase tracking-wider",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                    children: [
                                        'Nivel',
                                        'Grado',
                                        'Sección',
                                        'Capacidad',
                                        'Matrícula',
                                        'Estado',
                                        'Acción'
                                    ].map((label)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                            scope: "col",
                                            className: "py-3 px-4",
                                            children: label
                                        }, label, false, {
                                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                            lineNumber: 48,
                                            columnNumber: 198
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                    lineNumber: 48,
                                    columnNumber: 104
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                lineNumber: 48,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                children: result.data.map((section)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: "border-t border-line hover:bg-neutral/30 transition-colors",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "py-3 px-4",
                                                children: section.level === 'PRIMARY' ? 'Primaria' : 'Secundaria'
                                            }, void 0, false, {
                                                fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                lineNumber: 50,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "py-3 px-4 font-semibold",
                                                children: [
                                                    section.grade,
                                                    "°"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                lineNumber: 50,
                                                columnNumber: 103
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "py-3 px-4 font-bold break-words",
                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sectionName"])(section.name)
                                            }, void 0, false, {
                                                fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                lineNumber: 50,
                                                columnNumber: 164
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "py-3 px-4",
                                                children: section.maxCapacity
                                            }, void 0, false, {
                                                fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                lineNumber: 50,
                                                columnNumber: 244
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "py-3 px-4",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionBadge"], {
                                                    positive: section.enrollmentOpen,
                                                    children: section.enrollmentOpen ? 'Abierta' : 'Cerrada'
                                                }, void 0, false, {
                                                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                    lineNumber: 50,
                                                    columnNumber: 322
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                lineNumber: 50,
                                                columnNumber: 296
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "py-3 px-4",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SectionBadge"], {
                                                    positive: section.active,
                                                    children: section.active ? 'Activo' : 'Inactivo'
                                                }, void 0, false, {
                                                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                    lineNumber: 50,
                                                    columnNumber: 464
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                lineNumber: 50,
                                                columnNumber: 438
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                className: "py-3 px-4",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["secondaryButtonClass"]} inline-flex items-center gap-1.5 whitespace-nowrap hover:bg-accent hover:text-white hover:border-accent group/action`,
                                                    href: `/administrador/secciones/${section.id}`,
                                                    "aria-label": `Ver cursos de ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$feature$2f$admin$2f$vistas$2f28$academico$292f$secciones$2f$sectionUi$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sectionName"])(section.name)}, grado ${section.grade}`,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$BookOpen01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BookOpen01Icon"], {
                                                            size: 15,
                                                            "aria-hidden": "true"
                                                        }, void 0, false, {
                                                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                            lineNumber: 51,
                                                            columnNumber: 332
                                                        }, this),
                                                        "Ver cursos",
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hugeicons$2d$react$2f$dist$2f$esm$2f$icons$2f$ArrowRight01Icon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ArrowRight01Icon"], {
                                                            size: 14,
                                                            "aria-hidden": "true",
                                                            className: "group-hover/action:translate-x-0.5 transition-transform"
                                                        }, void 0, false, {
                                                            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                            lineNumber: 51,
                                                            columnNumber: 389
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                    lineNumber: 51,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                                lineNumber: 51,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, section.id, true, {
                                        fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                        lineNumber: 49,
                                        columnNumber: 48
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                                lineNumber: 49,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                        lineNumber: 47,
                        columnNumber: 93
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
                    lineNumber: 47,
                    columnNumber: 11
                }, this))
            ]
        }, void 0, true, {
            fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
            lineNumber: 24,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/feature/admin/vistas/(academico)/secciones/vistaSecciones.tsx",
        lineNumber: 23,
        columnNumber: 10
    }, this);
}
_s(VistaSecciones, "YKlKJY1Q8yMsmHzQMixVUgR1MQY=");
_c = VistaSecciones;
var _c;
__turbopack_context__.k.register(_c, "VistaSecciones");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/admin/sectionErrors.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sectionErrorMessage",
    ()=>sectionErrorMessage,
    "sectionErrorStatus",
    ()=>sectionErrorStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/axios/index.js [app-client] (ecmascript) <locals>");
;
function sectionErrorStatus(error) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isAxiosError"])(error) ? error.response?.status : undefined;
}
function sectionErrorMessage(error, conflict = 'La operación entra en conflicto con el estado actual.') {
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isAxiosError"])(error)) return error instanceof Error ? error.message : 'No se pudo completar la solicitud. Intenta nuevamente.';
    if (!error.response) return 'No se pudo conectar con el servidor. Revisa tu conexión y vuelve a intentar.';
    const body = error.response.data;
    const message = typeof body === 'string' ? body : body && typeof body === 'object' && 'message' in body && typeof body.message === 'string' ? body.message : undefined;
    let result;
    switch(error.response.status){
        case 400:
            result = message || 'Los datos enviados no son válidos.';
            break;
        case 401:
            result = 'Tu sesión no permite completar la solicitud.';
            break;
        case 403:
            result = 'No tienes permisos para realizar esta operación.';
            break;
        case 404:
            result = message || 'El recurso solicitado no existe.';
            break;
        case 409:
            result = message || conflict;
            break;
        case 422:
            result = message || 'No se cumple una regla de negocio. Verifica que los recursos estén activos y sean compatibles.';
            break;
        default:
            result = 'El servidor no pudo completar la solicitud. Intenta nuevamente.';
    }
    if ([
        409,
        422
    ].includes(error.response.status) && body && typeof body === 'object' && 'details' in body && body.details != null) {
        const details = typeof body.details === 'string' ? body.details : JSON.stringify(body.details, null, 2);
        if (details) result += `\n${details}`;
    }
    return result;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/admin/sectionsService.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sectionsService",
    ()=>sectionsService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$httpClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/httpClient.ts [app-client] (ecmascript)");
;
const endpoint = '/v1/management/sections';
const sectionsService = {
    async list (params = {}) {
        return (await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$httpClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(endpoint, {
            params
        })).data;
    },
    async getById (id) {
        return (await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$httpClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${endpoint}/${encodeURIComponent(id)}`)).data;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/services/httpClient.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
;
/**
 * Cliente HTTP estandarizado (Axios).
 * Configurado con la URL base del entorno.
 */ const httpClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:8080/api',
    headers: {
        'Content-Type': 'application/json'
    }
});
/**
 * Interceptor de Solicitudes (Request).
 * Adjunta el Bearer Token a todas las peticiones salientes si existe sesión.
 */ httpClient.interceptors.request.use((config)=>{
    if ("TURBOPACK compile-time truthy", 1) {
        const token = localStorage.getItem('token');
        if (token && config.headers) {
            config.headers.Authorization = `Bearer ${token}`;
        }
    }
    return config;
}, (error)=>Promise.reject(error));
/**
 * Interceptor de Respuestas (Response).
 * Atrapa los errores HTTP de forma global antes de que lleguen a los servicios.
 */ httpClient.interceptors.response.use((response)=>response, (error)=>{
    if (error.response?.status === 401) {
        if ("TURBOPACK compile-time truthy", 1) {
            // Se omite la expulsión si el error proviene del propio intento de login (401 de credenciales erróneas),
            // asegurando que sólo se expulsa cuando falla un token válido previamente asignado.
            const hasAuthHeader = !!error.config?.headers?.Authorization;
            if (hasAuthHeader) {
                window.dispatchEvent(new CustomEvent('auth:unauthorized'));
            }
        }
    }
    return Promise.reject(error);
});
const __TURBOPACK__default__export__ = httpClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);})()

//# sourceMappingURL=_1fgkzadqux1qa._.js.map