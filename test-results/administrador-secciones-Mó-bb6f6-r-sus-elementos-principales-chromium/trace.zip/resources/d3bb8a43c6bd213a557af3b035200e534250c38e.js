(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_1gdxm4-15jjh5._.js","static/chunks/src_app_globals_162hn9oqc8uss.css","static/chunks/node_modules_11mv_hyfit8pk._.js","static/chunks/_0xalvszxyo3na._.js","static/chunks/node_modules_0uxx5sua_d4w5._.js","static/chunks/_1fgkzadqux1qa._.js"],
    source: "entry"
});
